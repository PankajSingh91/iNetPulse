from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('packet-analysis/', views.packet_analysis, name='packet_analysis'),
    path('performance-analysis/', views.performance_analysis, name='performance_analysis'),
    path('traffic-analysis/', views.traffic_analysis, name='traffic_analysis'),
    path('anomaly-detection/', views.anomaly_detection, name='anomaly_detection'),
    path('protocol-detection/', views.protocol_detection, name='protocol_detection'),
    path('setup-alerts/', views.setup_alerts, name='setup_alerts'),
]
